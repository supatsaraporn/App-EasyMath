package com.example.easymath;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Area extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_area);

        Button circle = (Button)findViewById(R.id.CIRCLE);
        Button square = (Button) findViewById(R.id.SQUARE);
        Button triangle = (Button) findViewById(R.id.TRIANGLE);
        Button back_area_to_menu = (Button) findViewById(R.id.back_area_to_menu);
        back_area_to_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openmenu();
            }
        });

        //Action Button//
        circle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCircle();
            }
        });

        square.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSquare();
            }
        });

        triangle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTriangle();
            }
        });
    }

    public void openmenu(){
        Intent intent = new Intent(this,Menu.class);
        startActivity(intent);
    }

    public void openCircle(){
        Intent intent = new Intent(this,Circle.class);
        startActivity(intent);
    }

    public void openSquare(){
        Intent intent = new Intent(this,Square.class);
        startActivity(intent);
    }

    public void openTriangle(){
        Intent intent = new Intent(this,Triangle.class);
        startActivity(intent);
    }


}
