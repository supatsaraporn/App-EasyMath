package com.example.easymath;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Calculator extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);

        final EditText num1 = (EditText)findViewById(R.id.num1);
        final EditText num2 = (EditText)findViewById(R.id.num2);
        Button add = (Button)findViewById(R.id.add);
        Button sub = (Button)findViewById(R.id.sub);
        Button mul = (Button)findViewById(R.id.mul);
        Button div = (Button)findViewById(R.id.div);
        final TextView Answer = (TextView) findViewById(R.id.Answer_cal);
        Button back = (Button)findViewById(R.id.back_cal_to_menu);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMenu();
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double x = Integer.parseInt(num1.getText().toString());
                double y = Integer.parseInt(num2.getText().toString());

                double result = (x + y);

                Answer.setText(String.valueOf(result));
            }
        });

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double x = Integer.parseInt(num1.getText().toString());
                double y = Integer.parseInt(num2.getText().toString());

                double result = (x - y);

                Answer.setText(String.valueOf(result));
            }
        });

        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double x = Integer.parseInt(num1.getText().toString());
                double y = Integer.parseInt(num2.getText().toString());

                double result = (x * y);

                Answer.setText(String.valueOf(result));
            }
        });

        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double x = Integer.parseInt(num1.getText().toString());
                double y = Integer.parseInt(num2.getText().toString());

                double result = (x / y);

                Answer.setText(String.valueOf(result));
            }
        });
    }
    public void openMenu(){
        Intent intent = new Intent(this,Menu.class);
        startActivity(intent);
    }

}
