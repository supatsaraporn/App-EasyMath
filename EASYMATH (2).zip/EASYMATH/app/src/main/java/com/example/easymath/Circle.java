package com.example.easymath;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Circle extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_circle);

        final EditText radius = (EditText) findViewById(R.id.Radius);
        final TextView ans = (TextView) findViewById(R.id.Answer_circle);
        Button back_circle_to_area = (Button) findViewById(R.id.back_circle_to_area);
        back_circle_to_area.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openArea();
            }
        });
        Button answer = (Button) findViewById(R.id.ans_cir);

        //Action //
        answer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double x = Integer.parseInt(radius.getText().toString());
                double answer = (22/7 * x * x);

                ans.setText(String.valueOf(answer));
            }
        });
    }

    public void openArea(){
        Intent intent = new Intent(this,Area.class);
        startActivity(intent);
    }
}
