package com.example.easymath;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Game extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        Button play = (Button) findViewById(R.id.playaGame);
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMiniGame();
            }
        });

        Button back = (Button) findViewById(R.id.back_game_to_menu);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMenu();
            }
        });
    }
    public void openMiniGame(){
        Intent intent = new Intent(this,MiniGame.class);
        startActivity(intent);
    }

    public void openMenu(){
        Intent intent = new Intent(this,Menu.class);
        startActivity(intent);
    }
}
