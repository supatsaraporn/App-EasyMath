package com.example.easymath;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        Button cal = (Button) findViewById(R.id.CALCULATOR);
        cal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCalculator();
            }
        });


        Button area = (Button) findViewById(R.id.AREA);
        area.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openArea();
            }
        });

        Button mini = (Button) findViewById(R.id.GAME);
        mini.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGame();
            }
        });


        Button exit2 = (Button) findViewById(R.id.EXIT2);
        exit2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                System.exit(0);
            }
        });
    }



    public void openArea(){
        Intent intent = new Intent(this,Area.class);
        startActivity(intent);
    }

    public void openGame(){
        Intent intent = new Intent(this,Game.class);
        startActivity(intent);
    }

    public void openCalculator(){
        Intent intent = new Intent(this,Calculator.class);
        startActivity(intent);
    }




}
