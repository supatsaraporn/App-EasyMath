package com.example.easymath;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Square extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_square);

        final EditText wide = (EditText) findViewById(R.id.wide);
        final EditText long1 = (EditText) findViewById(R.id.num);
        final TextView ans = (TextView) findViewById(R.id.answer_square);
        Button back = (Button) findViewById(R.id.back_square_to_area);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openArea();
            }
        });
        Button answer = (Button) findViewById(R.id.ans_squ);

        //Action//
        answer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int x = Integer.parseInt(wide.getText().toString());
                int y = Integer.parseInt(long1.getText().toString());

                int answer = (x*y);

                ans.setText(String.valueOf(answer));

            }
        });
    }

    public void openArea(){
        Intent intent = new Intent(this, Area.class);
        startActivity(intent);


    }
}
