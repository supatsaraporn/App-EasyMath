package com.example.easymath;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Triangle extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_triangle);

        final EditText base = (EditText) findViewById(R.id.base);
        final EditText high = (EditText) findViewById(R.id.high);
        final TextView ans = (TextView) findViewById(R.id.answer_triangle);
        Button back = (Button) findViewById(R.id.back_triangle_to_area2);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openArea();
            }
        });
        Button answer = (Button) findViewById(R.id.ans_tri);

        //Action//
        answer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double x = Integer.parseInt(base.getText().toString());
                double y = Integer.parseInt(high.getText().toString());

                double answer = ( 0.5 * x * y);

                ans.setText(String.valueOf(answer));
            }
        });

    }

    public void openArea(){
        Intent intent = new Intent(this,Area.class);
        startActivity(intent);
    }
}
